const config = {
	API_URL: 'https://jpwp.fkor.us/'
};

export default config;
