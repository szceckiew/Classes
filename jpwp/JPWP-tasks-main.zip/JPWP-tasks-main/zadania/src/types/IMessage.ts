export default interface IMessage {
	author: string,
	content: string,
	date: Date
}
